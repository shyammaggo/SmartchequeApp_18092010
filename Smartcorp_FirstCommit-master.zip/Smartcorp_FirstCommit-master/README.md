# Smartcorp_FirstCommit
 CheuqeApp is committed. 
In this code below tasks are checked in.
1. Create Cheque screen
2. Validations.
3. View cheque screen after entering  all the valid data.
4. WebAPI code with S.O.L.I.D. principles and Repository Design Pattern.
I have used the below skills:
1. Angular
2. .NET Core Web API
3. Local SQL DB to make a API Call from Angular.
